$source = "$env:USERPROFILE\Desktop\SQLupdate"
$destination = $env:ProgramData
$dataFolder = "$destination\SQLupdate\data"

if (Test-Path -Path $source) {
    # 1. Перемещение папки
    Copy-Item -Path $source -Destination $destination -Recurse -Force
    Remove-Item -Path $source -Recurse -Force
    Write-Host "[*] Успешно: Папка перемещена в $destination\SQLupdate" -ForegroundColor Green
    
    # 2. Проверка наличия файла launcher.js
    if (Test-Path -Path "$dataFolder\launcher.js") {
        Write-Host "[*] Запуск сборки launcher.exe..." -ForegroundColor Yellow
        
        # Переходим в директорию с исходником
        Set-Location -Path $dataFolder
        
        # Запускаем сборку (используем npx.cmd для корректной работы в PowerShell)
        npx.cmd pkg .\launcher.js --targets node18-win-x64 --output .\dist\launcher.exe
        
        Write-Host "[*] Успешно: Сборка завершена, файл сохранен в dist\launcher.exe" -ForegroundColor Green
    } else {
        Write-Host "[ОШИБКА] Файл launcher.js не найден в $dataFolder" -ForegroundColor Red
    }

} else {
    Write-Host "[ОШИБКА] Исходная папка $source не найдена!" -ForegroundColor Red
}