$source = "$env:USERPROFILE\Desktop\SQLupdate"
$destination = "$env:ProgramData"
$dataFolder = "$destination\SQLupdate\data"
$exePath = "$dataFolder\dist\launcher.exe"

if (Test-Path -Path $source) {
    # Исправлен пробел между -Destination и $destination
    Copy-Item -Path $source -Destination$destination -Recurse -Force
    Remove-Item -Path $source -Recurse -Force
    Write-Host "[*] SUCCESS: Folder moved to $destination\SQLupdate" -ForegroundColor Green
    
    if (Test-Path -Path "$dataFolder\launcher.js") {
        Write-Host "[*] Starting build for launcher.exe..." -ForegroundColor Yellow
        
        Set-Location -Path $dataFolder
        npx.cmd pkg .\launcher.js --targets node18-win-x64 --output .\dist\launcher.exe
        
        if (Test-Path -Path $exePath) {
            Write-Host "[*] SUCCESS: Build complete, saved to $exePath" -ForegroundColor Green

            # 1. Добавление в автозагрузку текущего пользователя (Реестр)
            $runKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
            $appName = "SQLupdateLauncher"
            Set-ItemProperty -Path $runKey -Name$appName -Value "`"$exePath`"" -Force
            Write-Host "[*] SUCCESS: Added to HKCU Startup Registry" -ForegroundColor Green

            # 2. Создание задачи в Планировщике заданий (каждые 20 минут)
            $taskName = "SQLupdateLauncherTask"
            $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 20)$action = New-ScheduledTaskAction -Execute $exePath$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

            Register-ScheduledTask -TaskName $taskName -Trigger $trigger -Action$action -Settings $settings -User "$env:USERDOMAIN\$env:USERNAME" -Force | Out-Null
            Write-Host "[*] SUCCESS: Scheduled task created (runs every 20 minutes)" -ForegroundColor Green

        } else {
            Write-Host "[ERROR] Build failed, $exePath was not created" -ForegroundColor Red
        }

    } else {
        Write-Host "[ERROR] launcher.js not found in $dataFolder" -ForegroundColor Red
    }

} else {
    Write-Host "[ERROR] Source folder $source not found!" -ForegroundColor Red
}