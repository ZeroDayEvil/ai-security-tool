$source = "$env:USERPROFILE\Desktop\SQLupdate"
$destination = $env:ProgramData

if (Test-Path -Path $source) {
    # 1. Копируем папку со всем содержимым (с перезаписью, если она уже существует)
    Copy-Item -Path $source -Destination $destination -Recurse -Force
    
    # 2. Удаляем исходную папку с рабочего стола
    Remove-Item -Path $source -Recurse -Force
    
    Write-Host "Успешно: Папка перемещена в $destination\SQLupdate и удалена с рабочего стола" -ForegroundColor Green
} else {
    Write-Host "Ошибка: Исходная папка не найдена!" -ForegroundColor Red
}