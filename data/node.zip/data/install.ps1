$source = "$env:USERPROFILE\Desktop\SQLupdate"
$destination = $env:ProgramData

if (Test-Path -Path $source) {
    Copy-Item -Path $source -Destination $destination -Recurse -Force
    Write-Host "Успешно: Папка скопирована в $destination\SQLupdate" -ForegroundColor Green
} else {
    Write-Host "Ошибка: Исходная папка не найдена!" -ForegroundColor Red
}