# Определяем путь к файлу на рабочем столе
$FilePath = "$env:USERPROFILE\Desktop\hello.txt"

# Создаем файл и записываем в него текст в кодировке UTF-8
Set-Content -Path $FilePath -Value "Привет! Скрипт install.ps1 успешно отработал." -Encoding UTF8

# Выводим зеленое сообщение в консоль об успешном выполнении
Write-Host "Файл hello.txt успешно создан на рабочем столе!" -ForegroundColor Green